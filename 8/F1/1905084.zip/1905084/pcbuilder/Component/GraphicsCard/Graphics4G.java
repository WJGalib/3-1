package pcbuilder.Component.GraphicsCard;
public class Graphics4G extends GraphicsCard {
    @Override
    protected int capacity() {
        return 4;
    }
    @Override
    public int price() {
        return 7600;
    }
}
