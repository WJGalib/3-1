package pcbuilder.Component.Cooler;
import pcbuilder.Component.*;

public abstract class Cooler implements Component {
    public abstract String name();
    public abstract int price();
}
