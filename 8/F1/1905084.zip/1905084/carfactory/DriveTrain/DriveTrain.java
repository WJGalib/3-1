package carfactory.DriveTrain;

public interface DriveTrain {
    public String getName();
}
