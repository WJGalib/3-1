package pcbuilder.Component.Processor;

public class IntelCi9 extends Processor {
    @Override
    public String name() {
        return "Intel Core-i9 11th Gen";
    }
    @Override
    public int price() {
        return 65000;
    }
}
