public interface TransportMedium
{
    public void transport();
}