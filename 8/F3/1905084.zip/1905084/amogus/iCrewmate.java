package amogus;

public interface iCrewmate {
    public String getName();

    public void fixWiring();
    public void cleanVent();
    public void startReactor();
    public void cleanOxygenFilters();
    public void alignEngines();
    public void makeBurger();
    public void emptyGarbage();
}
