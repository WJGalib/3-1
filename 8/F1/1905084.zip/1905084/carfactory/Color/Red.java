package carfactory.Color;

public class Red implements Color {
    public String getName() {
        return "Red";
    }
}
