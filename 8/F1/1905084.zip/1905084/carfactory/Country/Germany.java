package carfactory.Country;

public class Germany implements Country {
    public String getName() {
        return "Germany";
    }
}
