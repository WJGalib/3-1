package carfactory.Engine;

public class ElectricEngine implements Engine {
    public String getName() {
        return "Elecric";
    }
}
