package pcbuilder.Component.Processor;

public class Ryzen7 extends Processor {
    @Override
    public String name() {
        return "AMD Ryzen 7 5700X";
    }
    @Override
    public int price() {
        return 28000;
    }
}
