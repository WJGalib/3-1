package pcbuilder.Component.Cooler;
public class CpuCooler extends Cooler {
    @Override
    public String name() {
        return "CPU Cooler";
    }
    @Override
    public int price() {
        return 36000;
    }
}
