package pcbuilder.Component.Processor;

public class IntelCi7 extends Processor {
    @Override
    public String name() {
        return "Intel Core-i7 11th Gen";
    }
    @Override
    public int price() {
        return 36000;
    }
}
