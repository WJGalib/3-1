package shakebuilder.Component;

public class RegularMilk extends Milk {
    @Override
    public String name() {
        return "Milk";
    }
    @Override
    public int price() {
        return 0;
    }
}
