package pcbuilder.Component.Processor;
import pcbuilder.Component.*;

public abstract class Processor implements Component {
    public abstract String name();
    public abstract int price();
}