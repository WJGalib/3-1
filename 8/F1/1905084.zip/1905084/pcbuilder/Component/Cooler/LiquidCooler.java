package pcbuilder.Component.Cooler;
public class LiquidCooler extends Cooler {
    @Override
    public String name() {
        return "Liquid Cooler";
    }
    @Override
    public int price() {
        return 17000;
    }
}
