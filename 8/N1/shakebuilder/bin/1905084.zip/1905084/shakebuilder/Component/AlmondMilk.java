package shakebuilder.Component;

public class AlmondMilk extends Milk {
    @Override
    public String name() {
        return "Almond Milk";
    }
    @Override
    public int price() {
        return 60;
    }
}
