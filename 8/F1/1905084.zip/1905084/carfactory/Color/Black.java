package carfactory.Color;

public class Black implements Color {
    public String getName() {
        return "Black";
    }
}
