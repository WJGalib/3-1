package pcbuilder.Component.Memory;
public class Mem2666 extends Memory {
    @Override
    protected int frequency() {
        return 2666;
    }
    @Override
    public int price() {
        return 2620;
    }
}
