package carfactory.Country;

public class Japan implements Country {
    public String getName() {
        return "Japan";
    }
}
