package shakebuilder.Component;

public class ChocolateIcecream implements Component {

    @Override
    public String name() {
        return "Chocolate_ice_cream";
    }
    @Override
    public int price() {
        return 0;
    }
}
