package carfactory.Country;

public interface Country {
    public String getName();
}
