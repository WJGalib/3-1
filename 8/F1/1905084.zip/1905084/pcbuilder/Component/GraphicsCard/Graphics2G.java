package pcbuilder.Component.GraphicsCard;
public class Graphics2G extends GraphicsCard {
    @Override
    protected int capacity() {
        return 2;
    }
    @Override
    public int price() {
        return 6500;
    }
}
