package exam;
import exam.Person.Person;

public interface Mediator {

    public abstract void sendFrom (Person p, Score s);
}
