package shakebuilder.Component;

public class ChocolateSyrup implements Component {

    @Override
    public String name() {
        return "Chocolate_syrup";
    }
    @Override
    public int price() {
        return 0;
    }
}
