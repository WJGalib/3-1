package carfactory.Country;

public class USA implements Country {
    public String getName() {
        return "USA";
    }
}
