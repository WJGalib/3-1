package pcbuilder.Component.Memory;
public class Mem3200 extends Memory {
    @Override
    protected int frequency() {
        return 3200;
    }
    @Override
    public int price() {
        return 2950;
    }
}
