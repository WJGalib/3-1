package shakebuilder.Component;

public class Sugar implements Component {
    @Override
    public String name() {
        return "Sugar";
    }
    @Override
    public int price() {
        return 0;
    }
}
