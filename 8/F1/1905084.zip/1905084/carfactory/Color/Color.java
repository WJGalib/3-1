package carfactory.Color;

public interface Color {
    public String getName();
}
