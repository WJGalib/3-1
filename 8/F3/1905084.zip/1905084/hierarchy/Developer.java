package hierarchy;

public class Developer extends Leaf {
    public Developer (String name, String proj) {
        super (name, "Developer", proj);
    }
}
