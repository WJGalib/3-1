g++ -std=c++17 assembler.cpp -o assembler 
./assembler

rm assembler