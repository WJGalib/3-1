package carfactory.DriveTrain;

public class AllWheel implements DriveTrain {
    public String getName() {
        return "All-Wheel";
    }
}
