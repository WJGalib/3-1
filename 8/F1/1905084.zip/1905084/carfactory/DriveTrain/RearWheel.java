package carfactory.DriveTrain;

public class RearWheel implements DriveTrain {
    public String getName() {
        return "Rear Wheel";
    }
}
