package carfactory.Engine;

public interface Engine {
    public String getName();
}
