package carfactory.Engine;

public class HydrogenFuelCell implements Engine {
    public String getName() {
        return "Hydrogen Fuel Cell";
    }
}
