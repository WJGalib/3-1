package carfactory.Color;

public class White implements Color {
    public String getName() {
        return "White";
    }
}
