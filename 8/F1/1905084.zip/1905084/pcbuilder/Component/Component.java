package pcbuilder.Component;

public interface Component {
    public String name();
    public int price();
}
